﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using Lesson5Train.Resources;
using System.IO.IsolatedStorage;



namespace Lesson5Train
{
    public partial class MainPage : PhoneApplicationPage
    {
        IsolatedStorageSettings settings = IsolatedStorageSettings.ApplicationSettings;
        // Constructor
        public MainPage()
        {
            InitializeComponent();

            // Sample code to localize the ApplicationBar
            //BuildLocalizedApplicationBar();
        }

        //variables
        bool validated1;
        bool validated2;
        bool validated3;
        bool validated4;
        int duration;
        //bool validated5;

        private void tbHour_TextChanged(object sender, TextChangedEventArgs e)
        {
           // tbHour.Text = string.Empty;
        }

        private void tbHour_GotFocus(object sender, RoutedEventArgs e)
        {
            TextBox tb = (TextBox)sender;
            tb.Text = string.Empty;
            tb.GotFocus -= tbHour_GotFocus;
        }

        private void tbMinute_GotFocus(object sender, RoutedEventArgs e)
        {
            TextBox tb = (TextBox)sender;
            tb.Text = string.Empty;
            tb.GotFocus -= tbMinute_GotFocus;
        }

        private void tbTrip_GotFocus(object sender, RoutedEventArgs e)
        {
            TextBox tb = (TextBox)sender;
            tb.Text = string.Empty;
            tb.GotFocus -= tbTrip_GotFocus;
        }

        private void submit_Click(object sender, RoutedEventArgs e)
        {
            //gather data from textboxes
            //&
            // convert trip duration
            //&
            //validation
            //&
            //everything else
            
            if(duration > 1500)
            {
                string message = "Trip duration must not exceed 1500 minutes";
                string caption = "Invalid entry";
                
                MessageBox.Show(message, caption, MessageBoxButton.OKCancel);
                
            }
            else
            {
                validated1 = true;
            }

            //int hours = Convert.ToInt32(duration) / 60;
            //int minutes = Convert.ToInt32(duration) % 60;

            int boardingHour = Convert.ToInt32(tbHour.Text);
            if (boardingHour > 23)
            {
                string message2 = "Boarding Hour cannot  be greater than 23";
                string caption2 = "Invalid entry";
                MessageBox.Show(message2, caption2, MessageBoxButton.OKCancel);
            }
            else
            {
                validated2 = true;
            }
            
            int boardingMinute = Convert.ToInt32(tbMinute.Text);
            if(boardingMinute > 59)
            {
                string message3 = "Boarding Minute cannot  be greater than 59";
                string caption3 = "Invalid entry";
                MessageBox.Show(message3, caption3, MessageBoxButton.OKCancel);
            }
            else
            {
                validated3 = true;
            }
            
           // int arrivalHour = 
            


            

            
            //das settings
            duration = Convert.ToInt32(tbTrip.Text);
            settings.Add("tripTime", duration);
            settings.Add("boardingHour", boardingHour);
            settings.Add("boardingMinute", boardingMinute);

            settings.Save();
            
           

            //if everything validates, proceed to next page
            if((validated1 = true) && (validated2 = true) && (validated3 = true))
            {
                

                NavigationService.Navigate(new Uri("/Page2.xaml", UriKind.Relative));
            }
            

        }

        private void tbHour_LostFocus(object sender, RoutedEventArgs e)
        {
            
        }

        // Sample code for building a localized ApplicationBar
        //private void BuildLocalizedApplicationBar()
        //{
        //    // Set the page's ApplicationBar to a new instance of ApplicationBar.
        //    ApplicationBar = new ApplicationBar();

        //    // Create a new button and set the text value to the localized string from AppResources.
        //    ApplicationBarIconButton appBarButton = new ApplicationBarIconButton(new Uri("/Assets/AppBar/appbar.add.rest.png", UriKind.Relative));
        //    appBarButton.Text = AppResources.AppBarButtonText;
        //    ApplicationBar.Buttons.Add(appBarButton);

        //    // Create a new menu item with the localized string from AppResources.
        //    ApplicationBarMenuItem appBarMenuItem = new ApplicationBarMenuItem(AppResources.AppBarMenuItemText);
        //    ApplicationBar.MenuItems.Add(appBarMenuItem);
        //}
    }
}