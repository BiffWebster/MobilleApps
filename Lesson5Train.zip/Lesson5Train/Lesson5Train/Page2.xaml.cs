﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using System.IO.IsolatedStorage;

namespace Lesson5Train
{
    public partial class Page2 : PhoneApplicationPage
    {
        IsolatedStorageSettings settings = IsolatedStorageSettings.ApplicationSettings;
        public Page2()
        {
            InitializeComponent();
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            var store = IsolatedStorageSettings.ApplicationSettings;
            int hours = (int)store["tripTime"] / 60;
            int minutes = (int)store["tripTime"] % 60;
            int boardingMinute = (int)store["boardingMinute"];
            int boardingHour = (int)store["boardingHour"];
            int arrivalHour = boardingHour + hours;
            if (arrivalHour > 23)
            {
                arrivalHour = (boardingHour + hours) - 23;
            }
            int arrivalMinute = boardingMinute + minutes;

            if(arrivalMinute > 60)
            {
                arrivalMinute = (boardingMinute + minutes) - 60;
            }
            arrivalTime.Text = String.Format("{0} : {1}", arrivalHour, arrivalMinute);
            if(arrivalHour < 7)
            {
                weary.Visibility = Visibility.Visible;
                redeye.Visibility = Visibility.Visible;

            }
        }
    }
}