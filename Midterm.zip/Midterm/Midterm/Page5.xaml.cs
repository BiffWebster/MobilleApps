﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkID=390556

namespace Midterm
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class Page5 : Page
    {
        public Page5()
        {
            this.InitializeComponent();
        }

        bool right;
        /// <summary>
        /// Invoked when this page is about to be displayed in a Frame.
        /// </summary>
        /// <param name="e">Event data that describes how this page was reached.
        /// This parameter is typically used to configure the page.</param>
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            japan.Background = new SolidColorBrush(Windows.UI.Colors.Red);
            buzzer.Play();
            incorrect.Visibility = Windows.UI.Xaml.Visibility.Visible;
            southkorea.Background = new SolidColorBrush(Windows.UI.Colors.Green);
            northkorea.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
            taiwan.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
            next.Visibility = Windows.UI.Xaml.Visibility.Visible;
        }

        private void southkorea_Click(object sender, RoutedEventArgs e)
        {

            southkorea.Background = new SolidColorBrush(Windows.UI.Colors.Green);
            bell.Play();
            correct.Visibility = Windows.UI.Xaml.Visibility.Visible;
            right = true;
            japan.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
            northkorea.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
            taiwan.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
            next.Visibility = Windows.UI.Xaml.Visibility.Visible;
        }

        private void taiwan_Click(object sender, RoutedEventArgs e)
        {
            northkorea.Background = new SolidColorBrush(Windows.UI.Colors.Red);
            buzzer.Play();
            incorrect.Visibility = Windows.UI.Xaml.Visibility.Visible;
            southkorea.Background = new SolidColorBrush(Windows.UI.Colors.Green);
            taiwan.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
            japan.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
            next.Visibility = Windows.UI.Xaml.Visibility.Visible;
        }

        private void northkorea_Click(object sender, RoutedEventArgs e)
        {
            taiwan.Background = new SolidColorBrush(Windows.UI.Colors.Red);
            buzzer.Play();
            incorrect.Visibility = Windows.UI.Xaml.Visibility.Visible;
            southkorea.Background = new SolidColorBrush(Windows.UI.Colors.Green);
            northkorea.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
            japan.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
            next.Visibility = Windows.UI.Xaml.Visibility.Visible;
        }

        private void next_Click(object sender, RoutedEventArgs e)
        {
            if (right == true)
            {
                // Counter.noCorrect = 1;
                Frame.Navigate(typeof(Page6), Counter.noCorrect++);
            }
            else
            {
                //Counter.noCorrect = 0;
                Frame.Navigate(typeof(Page6), Counter.noCorrect);
            }
        }
    }
}
