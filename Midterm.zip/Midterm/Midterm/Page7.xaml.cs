﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkID=390556

namespace Midterm
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class Page7 : Page
    {
        public Page7()
        {
            this.InitializeComponent();
        }

        bool right;

        /// <summary>
        /// Invoked when this page is about to be displayed in a Frame.
        /// </summary>
        /// <param name="e">Event data that describes how this page was reached.
        /// This parameter is typically used to configure the page.</param>
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
        }

        private void india_Click(object sender, RoutedEventArgs e)
        {
            india.Background = new SolidColorBrush(Windows.UI.Colors.Green);
            bell.Play();
            correct.Visibility = Windows.UI.Xaml.Visibility.Visible;
            right = true;
            argentina.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
            myanmar.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
            pakistan.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
            next.Visibility = Windows.UI.Xaml.Visibility.Visible;
        }

        private void argentina_Click(object sender, RoutedEventArgs e)
        {
            argentina.Background = new SolidColorBrush(Windows.UI.Colors.Red);
            buzzer.Play();
            incorrect1.Visibility = Windows.UI.Xaml.Visibility.Visible;
            india.Background = new SolidColorBrush(Windows.UI.Colors.Green);
            myanmar.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
            pakistan.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
            next.Visibility = Windows.UI.Xaml.Visibility.Visible;
        }

        private void myanmar_Click(object sender, RoutedEventArgs e)
        {
            myanmar.Background = new SolidColorBrush(Windows.UI.Colors.Red);
            buzzer.Play();
            incorrect1.Visibility = Windows.UI.Xaml.Visibility.Visible;
            india.Background = new SolidColorBrush(Windows.UI.Colors.Green);
            pakistan.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
            argentina.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
            next.Visibility = Windows.UI.Xaml.Visibility.Visible;
        }

        private void pakistan_Click(object sender, RoutedEventArgs e)
        {
            pakistan.Background = new SolidColorBrush(Windows.UI.Colors.Red);
            buzzer.Play();
            incorrect1.Visibility = Windows.UI.Xaml.Visibility.Visible;
            india.Background = new SolidColorBrush(Windows.UI.Colors.Green);
            myanmar.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
            argentina.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
            next.Visibility = Windows.UI.Xaml.Visibility.Visible;
        }

        private void next_Click(object sender, RoutedEventArgs e)
        {
            if (right == true)
            {
                // Counter.noCorrect = 1;
                Frame.Navigate(typeof(Page8), Counter.noCorrect++);
            }
            else
            {
                //Counter.noCorrect = 0;
                Frame.Navigate(typeof(Page8), Counter.noCorrect);
            }
        }
    }
}
