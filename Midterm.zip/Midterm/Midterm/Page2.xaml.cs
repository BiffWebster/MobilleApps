﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using System.Windows;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkID=390556

namespace Midterm
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    
    
    public sealed partial class Page2 : Page
    {
        public bool right;
        public Page2()
        {
            this.InitializeComponent();
        }

        /// <summary>
        /// Invoked when this page is about to be displayed in a Frame.
        /// </summary>
        /// <param name="e">Event data that describes how this page was reached.
        /// This parameter is typically used to configure the page.</param>
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            italy.Background = new SolidColorBrush(Windows.UI.Colors.Red);
            buzzer.Play();
            incorrectTB.Visibility = Windows.UI.Xaml.Visibility.Visible;
            ireland.Background = new SolidColorBrush(Windows.UI.Colors.Green);
            romania.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
            mexico.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
            next.Visibility = Windows.UI.Xaml.Visibility.Visible;
        }

        //correct answer
        private void ireland_Click(object sender, RoutedEventArgs e)
        {
            ireland.Background = new SolidColorBrush(Windows.UI.Colors.Green);
            bell.Play();
            correctTB.Visibility = Windows.UI.Xaml.Visibility.Visible;
            right = true;
            italy.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
            romania.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
            mexico.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
            next.Visibility = Windows.UI.Xaml.Visibility.Visible;

        }

        private void romania_Click(object sender, RoutedEventArgs e)
        {
            romania.Background = new SolidColorBrush(Windows.UI.Colors.Red);
            buzzer.Play();
            incorrectTB.Visibility = Windows.UI.Xaml.Visibility.Visible;
            ireland.Background = new SolidColorBrush(Windows.UI.Colors.Green);
            mexico.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
            italy.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
            next.Visibility = Windows.UI.Xaml.Visibility.Visible;

        }

        private void mexico_Click(object sender, RoutedEventArgs e)
        {
            mexico.Background = new SolidColorBrush(Windows.UI.Colors.Red);
            buzzer.Play();
            incorrectTB.Visibility = Windows.UI.Xaml.Visibility.Visible;
            ireland.Background = new SolidColorBrush(Windows.UI.Colors.Green);
            romania.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
            italy.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
            next.Visibility = Windows.UI.Xaml.Visibility.Visible;
        }

        private void TextBlock_SelectionChanged(object sender, RoutedEventArgs e)
        {

        }

        private void HyperlinkButton_Click(object sender, RoutedEventArgs e)
        {
            //Counter myCounter = new Counter();


            if (right == true)
            {
               // Counter.noCorrect = 1;
                Frame.Navigate(typeof(Page3), Counter.noCorrect++);
            }
            else
            {
                //Counter.noCorrect = 0;
                Frame.Navigate(typeof(Page3), Counter.noCorrect);
            }

            
        }

       
    }
}
