﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkID=390556

namespace Midterm
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class Page4 : Page
    {
        public Page4()
        {
            this.InitializeComponent();
        }

        bool right;
        /// <summary>
        /// Invoked when this page is about to be displayed in a Frame.
        /// </summary>
        /// <param name="e">Event data that describes how this page was reached.
        /// This parameter is typically used to configure the page.</param>
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
           
        }
        
        private void TextBlock_SelectionChanged(object sender, RoutedEventArgs e)
        {
        }

        private void brazil_Click(object sender, RoutedEventArgs e)
        {
            brazil.Background = new SolidColorBrush(Windows.UI.Colors.Green);
            correct.Visibility = Windows.UI.Xaml.Visibility.Visible;
            right = true;

            paraguay.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
            uruguay.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
            chile.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
            next.Visibility = Windows.UI.Xaml.Visibility.Visible;
        }

        private void paraguay_Click(object sender, RoutedEventArgs e)
        {
            paraguay.Background = new SolidColorBrush(Windows.UI.Colors.Red);
            buzzer.Play();
            incorrect.Visibility = Windows.UI.Xaml.Visibility.Visible;
            brazil.Background = new SolidColorBrush(Windows.UI.Colors.Green);
            chile.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
            uruguay.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
            next.Visibility = Windows.UI.Xaml.Visibility.Visible;
        }

        private void uruguay_Click(object sender, RoutedEventArgs e)
        {
            uruguay.Background = new SolidColorBrush(Windows.UI.Colors.Red);
            buzzer.Play();
            incorrect.Visibility = Windows.UI.Xaml.Visibility.Visible;
            brazil.Background = new SolidColorBrush(Windows.UI.Colors.Green);
            paraguay.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
            chile.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
            next.Visibility = Windows.UI.Xaml.Visibility.Visible;
        }

        private void chile_Click(object sender, RoutedEventArgs e)
        {
            chile.Background = new SolidColorBrush(Windows.UI.Colors.Red);
            buzzer.Play();
            incorrect.Visibility = Windows.UI.Xaml.Visibility.Visible;
            brazil.Background = new SolidColorBrush(Windows.UI.Colors.Green);
            paraguay.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
            uruguay.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
            next.Visibility = Windows.UI.Xaml.Visibility.Visible;
        }

        private void next_Click(object sender, RoutedEventArgs e)
        {
            if (right == true)
            {
                // Counter.noCorrect = 1;
                Frame.Navigate(typeof(Page5), Counter.noCorrect++);
            }
            else
            {
                //Counter.noCorrect = 0;
                Frame.Navigate(typeof(Page5), Counter.noCorrect);
            }
        }
    }
}
