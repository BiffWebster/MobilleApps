﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkID=390556

namespace Midterm
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class Page8 : Page
    {
        public Page8()
        {
            this.InitializeComponent();
        }
        bool right;
        /// <summary>
        /// Invoked when this page is about to be displayed in a Frame.
        /// </summary>
        /// <param name="e">Event data that describes how this page was reached.
        /// This parameter is typically used to configure the page.</param>
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
        }

        private void russia_Click(object sender, RoutedEventArgs e)
        {
            russia.Background = new SolidColorBrush(Windows.UI.Colors.Green);
            bell.Play();
            correct.Visibility = Windows.UI.Xaml.Visibility.Visible;
            right = true;
            france.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
            poland.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
            iraq.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
            next.Visibility = Windows.UI.Xaml.Visibility.Visible;
        }

        private void france_Click(object sender, RoutedEventArgs e)
        {
             france.Background = new SolidColorBrush(Windows.UI.Colors.Red);
            buzzer.Play();
            incorrect.Visibility = Windows.UI.Xaml.Visibility.Visible;
            russia.Background = new SolidColorBrush(Windows.UI.Colors.Green);
            poland.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
            iraq.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
            next.Visibility = Windows.UI.Xaml.Visibility.Visible;
        }

        private void poland_Click(object sender, RoutedEventArgs e)
        {
             france.Background = new SolidColorBrush(Windows.UI.Colors.Red);
            buzzer.Play();
            incorrect.Visibility = Windows.UI.Xaml.Visibility.Visible;
            russia.Background = new SolidColorBrush(Windows.UI.Colors.Green);
            poland.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
            iraq.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
            next.Visibility = Windows.UI.Xaml.Visibility.Visible;
        }

        private void iraq_Click(object sender, RoutedEventArgs e)
        {
             france.Background = new SolidColorBrush(Windows.UI.Colors.Red);
            buzzer.Play();
            incorrect.Visibility = Windows.UI.Xaml.Visibility.Visible;
            russia.Background = new SolidColorBrush(Windows.UI.Colors.Green);
            poland.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
            iraq.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
            next.Visibility = Windows.UI.Xaml.Visibility.Visible;
        }

        private void next_Click(object sender, RoutedEventArgs e)
        {
            if (right == true)
            {
                // Counter.noCorrect = 1;
                Frame.Navigate(typeof(Page9), Counter.noCorrect++);
            }
            else
            {
                //Counter.noCorrect = 0;
                Frame.Navigate(typeof(Page9), Counter.noCorrect);
            }
        }
        
        
        }//endclass
    }//endnamespace

