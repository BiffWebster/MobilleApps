﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkID=390556

namespace Midterm
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class Page10 : Page
    {
        public Page10()
        {
            this.InitializeComponent();
        }

        /// <summary>
        /// Invoked when this page is about to be displayed in a Frame.
        /// </summary>
        /// <param name="e">Event data that describes how this page was reached.
        /// This parameter is typically used to configure the page.</param>
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
        }

        bool right;
        private void thailand_Click(object sender, RoutedEventArgs e)
        {
            thailand.Background = new SolidColorBrush(Windows.UI.Colors.Green);
            bell.Play();
            correct.Visibility = Windows.UI.Xaml.Visibility.Visible;
            right = true;
            paraguay.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
            russia.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
            singapore.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
            next.Visibility = Windows.UI.Xaml.Visibility.Visible;
        }

        private void paraguay_Click(object sender, RoutedEventArgs e)
        {
            russia.Background = new SolidColorBrush(Windows.UI.Colors.Red);
            buzzer.Play();
            incorrect.Visibility = Windows.UI.Xaml.Visibility.Visible;
            thailand.Background = new SolidColorBrush(Windows.UI.Colors.Green);
            singapore.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
            paraguay.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
            next.Visibility = Windows.UI.Xaml.Visibility.Visible;
        }

        private void russia_Click(object sender, RoutedEventArgs e)
        {
            russia.Background = new SolidColorBrush(Windows.UI.Colors.Red);
            buzzer.Play();
            incorrect.Visibility = Windows.UI.Xaml.Visibility.Visible;
            thailand.Background = new SolidColorBrush(Windows.UI.Colors.Green);
            singapore.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
            paraguay.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
            next.Visibility = Windows.UI.Xaml.Visibility.Visible;
        }

        private void singapore_Click(object sender, RoutedEventArgs e)
        {
            russia.Background = new SolidColorBrush(Windows.UI.Colors.Red);
            buzzer.Play();
            incorrect.Visibility = Windows.UI.Xaml.Visibility.Visible;
            thailand.Background = new SolidColorBrush(Windows.UI.Colors.Green);
            singapore.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
            paraguay.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
            next.Visibility = Windows.UI.Xaml.Visibility.Visible;
        }

        private void next_Click(object sender, RoutedEventArgs e)
        {
            if (right == true)
            {
                // Counter.noCorrect = 1;
                Frame.Navigate(typeof(Page11), Counter.noCorrect++);
            }
            else
            {
                //Counter.noCorrect = 0;
                Frame.Navigate(typeof(Page11), Counter.noCorrect);
            }
        }



    }
}
