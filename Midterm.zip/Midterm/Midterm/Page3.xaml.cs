﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkID=390556

namespace Midterm
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class Page3 : Page
    {
        public Page3()
        {
            this.InitializeComponent();
        }

        public bool right;
        /// <summary>
        /// Invoked when this page is about to be displayed in a Frame.
        /// </summary>
        /// <param name="e">Event data that describes how this page was reached.
        /// This parameter is typically used to configure the page.</param>
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            //Counter myCounter = new Counter();
            //testing1.Text = 
            //Counter data = e.Parameter as Counter;
            //Counter data = new Counter();
            //testing1.Text = Counter.noCorrect.ToString();
            
        }

        
        private void spainBtn_Click(object sender, RoutedEventArgs e)
        {
            spainBtn.Background = new SolidColorBrush(Windows.UI.Colors.Green);
            bellAudio.Play();
            correctTB.Visibility = Windows.UI.Xaml.Visibility.Visible;
            right = true;

            hungaryBtn.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
            srilankaBtn.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
            portugalBtn.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
            next.Visibility = Windows.UI.Xaml.Visibility.Visible;
        }

        private void srilankaBtn_Click(object sender, RoutedEventArgs e)
        {
            srilankaBtn.Background = new SolidColorBrush(Windows.UI.Colors.Red);
            buzzer.Play();
            incorrectTB1.Visibility = Windows.UI.Xaml.Visibility.Visible;
            spainBtn.Background = new SolidColorBrush(Windows.UI.Colors.Green);
            portugalBtn.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
            hungaryBtn.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
            next.Visibility = Windows.UI.Xaml.Visibility.Visible;

        }

        private void portugalBtn_Click(object sender, RoutedEventArgs e)
        {
            portugalBtn.Background = new SolidColorBrush(Windows.UI.Colors.Red);
            buzzer.Play();
            incorrectTB1.Visibility = Windows.UI.Xaml.Visibility.Visible;
            spainBtn.Background = new SolidColorBrush(Windows.UI.Colors.Green);
            srilankaBtn.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
            hungaryBtn.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
            next.Visibility = Windows.UI.Xaml.Visibility.Visible;
        }

        private void hungaryBtn_Click(object sender, RoutedEventArgs e)
        {
            hungaryBtn.Background = new SolidColorBrush(Windows.UI.Colors.Red);
            buzzer.Play();
            incorrectTB1.Visibility = Windows.UI.Xaml.Visibility.Visible;
            spainBtn.Background = new SolidColorBrush(Windows.UI.Colors.Green);
            srilankaBtn.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
            portugalBtn.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
            next.Visibility = Windows.UI.Xaml.Visibility.Visible;
        }

        private void TextBlock_SelectionChanged(object sender, RoutedEventArgs e)
        {

        }

        private void HyperlinkButton_Click(object sender, RoutedEventArgs e)
        {
            //Counter myCounter = new Counter();


            


        }

        private void HyperlinkButton_Click_1(object sender, RoutedEventArgs e)
        {
            if (right == true)
            {
                // Counter.noCorrect = 1;
                Frame.Navigate(typeof(Page4), Counter.noCorrect++);
            }
            else
            {
                //Counter.noCorrect = 0;
                Frame.Navigate(typeof(Page4), Counter.noCorrect);
            }
        }

        
    }
}
